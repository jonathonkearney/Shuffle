export default function arrayMax(array) {
  return Math.max.apply(Math, array); // eslint-disable-line prefer-spread
}
